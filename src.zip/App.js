import { useState, useEffect } from "react";
import { auth, db } from "./firebase";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import DriverApp from "./pages/DriverApp";
import AdminApp from "./pages/AdminApp";
import LoginApp from "./pages/LoginApp";
import PassengerApp from "./pages/PassengerApp";
import BoardingApp from "./pages/BoardingApp";
import PartnerApp from "./pages/PartnerApp";
import EmployeeApp from "./pages/EmployeeApp";

const path = window.location.pathname;
const isPassengerRoute = path.startsWith("/bus");
const isBoardingRoute = path.startsWith("/board");
const isPartnerRoute = path.startsWith("/partner");
const isEmployeeRoute = path.startsWith("/p") && !path.startsWith("/partner");

function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [companyId, setCompanyId] = useState(null);
  const [loading, setLoading] = useState(!isPassengerRoute && !isBoardingRoute && !isPartnerRoute && !isEmployeeRoute);

  useEffect(() => {
    if (isPassengerRoute || isBoardingRoute || isPartnerRoute || isEmployeeRoute) return;
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (u) {
        const snap = await getDoc(doc(db, "users", u.uid));
        if (snap.exists()) {
          const data = snap.data();
          setRole(data.role);
          setCompanyId(data.companyId || "dy001");
        } else {
          setRole("driver");
          setCompanyId("dy001");
        }
        setUser(u);
      } else {
        setUser(null); setRole(null); setCompanyId(null);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // ✅ /p → 통합 직원 앱 (로그인 불필요)
  if (isEmployeeRoute) return <EmployeeApp />;
  // ✅ /partner → 협력사 직원 등록 포털 (로그인 불필요)
  if (isPartnerRoute) return <PartnerApp />;
  // ✅ /board?t=TOKEN → 탑승 확인 앱 (로그인 불필요)
  if (isBoardingRoute) return <BoardingApp />;
  // ✅ /bus?c=... → 승객 위치 앱 (로그인 불필요)
  if (isPassengerRoute) return <PassengerApp />;

  if (loading) return (
    <div style={{ minHeight:"100vh", background:"#0B1A2E", display:"flex", alignItems:"center", justifyContent:"center", color:"#00C2FF", fontSize:18 }}>
      로딩 중...
    </div>
  );

  if (!user) return <LoginApp />;
  if (role === "admin" || role === "superadmin")
    return <AdminApp user={user} companyId={companyId} />;
  return <DriverApp companyId={companyId} />;
}

export default App;
